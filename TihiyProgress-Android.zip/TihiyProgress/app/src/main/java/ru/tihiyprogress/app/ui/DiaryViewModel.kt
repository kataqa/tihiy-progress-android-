package ru.tihiyprogress.app.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ru.tihiyprogress.app.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Date

class DiaryViewModel(private val repo: ProgressRepository) : ViewModel() {
    val entries = repo.entries.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    private val _unlocked = MutableStateFlow(false)
    val unlocked = _unlocked.asStateFlow()
    private val _hasPassword = MutableStateFlow<Boolean?>(null)
    val hasPassword = _hasPassword.asStateFlow()
    private var key: ByteArray? = null

    init { viewModelScope.launch { _hasPassword.value = repo.security() != null } }

    fun setPassword(password: String, onResult: (Boolean) -> Unit) = viewModelScope.launch {
        if (password.length < 6) { onResult(false); return@launch }
        val (security, derivedKey) = DiaryCrypto.createSecurity(password.toCharArray())
        repo.saveSecurity(security)
        key = derivedKey
        _unlocked.value = true
        _hasPassword.value = true
        onResult(true)
    }

    fun unlock(password: String, onResult: (Boolean) -> Unit) = viewModelScope.launch {
        val security = repo.security() ?: return@launch onResult(false)
        val derived = DiaryCrypto.unlock(password.toCharArray(), security)
        if (derived == null) onResult(false)
        else { key = derived; _unlocked.value = true; onResult(true) }
    }

    fun lock() { key?.fill(0); key = null; _unlocked.value = false }

    fun save(text: String, mood: String, editing: DiaryEntryEntity? = null) = viewModelScope.launch {
        val activeKey = key ?: return@launch
        val (encrypted, iv) = DiaryCrypto.encrypt(text, activeKey)
        if (editing == null) repo.addEntry(DiaryEntryEntity(createdAt = System.currentTimeMillis(), mood = mood, encryptedText = encrypted, iv = iv))
        else repo.updateEntry(editing.copy(mood = mood, encryptedText = encrypted, iv = iv))
    }

    fun decrypt(entry: DiaryEntryEntity): String? = try {
        key?.let { DiaryCrypto.decrypt(entry.encryptedText, entry.iv, it) }
    } catch (_: Exception) { null }

    fun delete(id: Long) = viewModelScope.launch { repo.deleteEntry(id) }
}
