package ru.tihiyprogress.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val reward: Int,
    val isBase: Boolean = false
)

@Entity(tableName = "app_stats")
data class StatsEntity(
    @PrimaryKey val id: Int = 1,
    val xp: Int = 0,
    val streak: Int = 0,
    val lastActiveDate: String = "",
    val lastBaseDate: String = "",
    val dailyDate: String = ""
)

@Entity(tableName = "diary_entries")
data class DiaryEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val createdAt: Long,
    val mood: String,
    val encryptedText: String,
    val iv: String
)

@Entity(tableName = "diary_security")
data class DiarySecurityEntity(
    @PrimaryKey val id: Int = 1,
    val salt: String,
    val verifier: String
)
