package ru.tihiyprogress.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.room.Room
import ru.tihiyprogress.app.data.*
import ru.tihiyprogress.app.ui.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val db by lazy { Room.databaseBuilder(applicationContext, AppDatabase::class.java, "tihiy-progress.db").build() }
    private val repository by lazy { ProgressRepository(db.dao()) }
    private val progressVm by viewModels<ProgressViewModel> { factory { ProgressViewModel(repository) } }
    private val diaryVm by viewModels<DiaryViewModel> { factory { DiaryViewModel(repository) } }

    @Suppress("UNCHECKED_CAST")
    private fun <T : ViewModel> factory(create: () -> T) = object : ViewModelProvider.Factory {
        override fun <VM : ViewModel> create(modelClass: Class<VM>): VM = create() as VM
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TihiyTheme { AppRoot(progressVm, diaryVm) } }
    }
}

private val Sage = Color(0xFF758F83)
private val Cream = Color(0xFFF4F0E9)
private val Ink = Color(0xFF303A35)

@Composable
fun TihiyTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val scheme = if (dark) darkColorScheme(
        primary = Color(0xFFB2C9BA), secondary = Color(0xFFD5BCA9),
        background = Color(0xFF171D1A), surface = Color(0xFF222A26)
    ) else lightColorScheme(
        primary = Sage, secondary = Color(0xFFB78F7B),
        background = Cream, surface = Color(0xFFFFFCF7), onBackground = Ink, onSurface = Ink
    )
    MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
}

@Composable
fun AppRoot(vm: ProgressViewModel, diaryVm: DiaryViewModel) {
    var tab by remember { mutableStateOf(0) }
    val state by vm.state.collectAsStateWithLifecycle()
    val tasks by vm.tasks.collectAsStateWithLifecycle()
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(state.message) {
        state.message?.let { snack.showSnackbar(it); vm.clearMessage() }
    }
    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Rounded.Spa, null) }, label = { Text("Мой путь") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Rounded.MenuBook, null) }, label = { Text("Дневник") })
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            if (tab == 0) HomeScreen(vm, state, tasks) else DiaryScreen(diaryVm)
        }
    }
}

@Composable
fun HomeScreen(vm: ProgressViewModel, state: ProgressUiState, tasks: List<TaskEntity>) {
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<TaskEntity?>(null) }
    val level = ProgressViewModel.level(state.stats.xp)
    val startXp = (level - 1) * (level - 1) * 50
    val endXp = level * level * 50
    val progress = ((state.stats.xp - startXp).toFloat() / (endXp - startXp)).coerceIn(0f, 1f)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Привет. Рады, что ты здесь.", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onBackground)
            Spacer(Modifier.height(16.dp))
            Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(22.dp)) {
                    Text("ТВОЙ ТЕМП", style = MaterialTheme.typography.labelMedium, letterSpacing = 2.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text("Уровень $level", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.weight(1f))
                        Text("${state.stats.xp} XP", style = MaterialTheme.typography.titleLarge)
                    }
                    Spacer(Modifier.height(14.dp))
                    LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(9.dp), strokeCap = androidx.compose.ui.graphics.StrokeCap.Round)
                    Spacer(Modifier.height(8.dp))
                    Text("${state.stats.xp} / $endXp XP до следующего уровня", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(16.dp))
                    Text("Серия: ${state.stats.streak} дн.  ·  Пропускать можно. Ты ничего не должен приложению.", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Небольшая идея на сегодня", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.weight(1f))
                        Icon(Icons.Rounded.WbTwilight, null, tint = MaterialTheme.colorScheme.primary)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(state.dailyTask, style = MaterialTheme.typography.bodyLarge)
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = vm::claimDaily, enabled = !state.dailyClaimed, modifier = Modifier.weight(1f)) { Text(if (state.dailyClaimed) "Уже выполнено" else "Сделал(а) · +30 XP") }
                        OutlinedButton(onClick = vm::adoptDaily) { Text("В список") }
                    }
                    Text("Если сегодня не подходит — ничего страшного. Завтра будет другое.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Самый маленький шаг", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text("Заглянуть сюда — уже действие. Не нужно ничего доказывать.", style = MaterialTheme.typography.bodyMedium)
                    }
                    Button(onClick = vm::claimBase, enabled = !state.baseClaimed) {
                        Text(if (state.baseClaimed) "Готово" else "+5 XP")
                    }
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Твои задания", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { showAdd = true }) { Icon(Icons.Rounded.Add, null); Text("Добавить") }
            }
        }
        if (tasks.isEmpty()) item { Text("Здесь пока пусто. Можно ничего не добавлять — или придумать одно очень простое дело.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(tasks, key = { it.id }) { task ->
            Card(shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(task.title, style = MaterialTheme.typography.titleMedium)
                        Text("+${task.reward} XP", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                    }
                    IconButton(onClick = { editing = task }) { Icon(Icons.Rounded.Edit, "Изменить") }
                    IconButton(onClick = { vm.deleteTask(task) }) { Icon(Icons.Rounded.DeleteOutline, "Удалить") }
                    Button(onClick = { vm.completeTask(task.reward); vm.deleteTask(task) }) { Text("Выполнено") }
                }
            }
        }
        item { Spacer(Modifier.height(12.dp)); Text("Тебе не нужно проходить этот путь быстро. Можно идти как получается.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }

    if (showAdd) TaskDialog(onDismiss = { showAdd = false }, onSave = { title, reward -> vm.addTask(title, reward); showAdd = false })
    editing?.let { task ->
        TaskDialog(initialTitle = task.title, initialReward = task.reward, onDismiss = { editing = null }, onSave = { title, reward -> vm.editTask(task, title, reward); editing = null })
    }
}

@Composable
fun TaskDialog(initialTitle: String = "", initialReward: Int = 10, onDismiss: () -> Unit, onSave: (String, Int) -> Unit) {
    var title by remember { mutableStateOf(initialTitle) }
    var reward by remember { mutableIntStateOf(initialReward) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initialTitle.isBlank()) "Новое задание" else "Изменить задание") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Что хотелось бы сделать?") }, singleLine = true)
                Text("Награда")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(5, 10, 20, 50).forEach { value ->
                        FilterChip(selected = reward == value, onClick = { reward = value }, label = { Text("$value XP") })
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onSave(title, reward) }, enabled = title.isNotBlank()) { Text("Сохранить") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
fun DiaryScreen(vm: DiaryViewModel) {
    val unlocked by vm.unlocked.collectAsStateWithLifecycle()
    val hasPassword by vm.hasPassword.collectAsStateWithLifecycle()
    val entries by vm.entries.collectAsStateWithLifecycle()
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    var editor by remember { mutableStateOf(false) }
    var editEntry by remember { mutableStateOf<DiaryEntryEntity?>(null) }
    var text by remember { mutableStateOf("") }
    var mood by remember { mutableStateOf("Спокойно") }
    var showEntry by remember { mutableStateOf<DiaryEntryEntity?>(null) }

    if (hasPassword == null) return
    if (!unlocked) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
            Icon(Icons.Rounded.MenuBook, null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(16.dp))
            Text(if (hasPassword == true) "Твой дневник закрыт" else "Личное пространство", style = MaterialTheme.typography.headlineSmall)
            Text(if (hasPassword == true) "Введи пароль, чтобы открыть записи." else "Придумай пароль от 6 символов. Записи будут храниться в зашифрованном виде на этом устройстве.")
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(password, { password = it; error = false }, label = { Text("Пароль") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), modifier = Modifier.fillMaxWidth())
            if (error) Text("Не получилось. Проверь пароль (минимум 6 символов).", color = MaterialTheme.colorScheme.error)
            Spacer(Modifier.height(12.dp))
            Button(onClick = {
                if (hasPassword == true) vm.unlock(password) { error = !it }
                else vm.setPassword(password) { error = !it }
            }, modifier = Modifier.fillMaxWidth()) { Text(if (hasPassword == true) "Открыть дневник" else "Создать дневник") }
        }
    } else {
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Место для себя", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
                    Text("Здесь можно быть честным(ой). Не обязательно писать красиво.")
                }
                IconButton(onClick = vm::lock) { Icon(Icons.Rounded.Lock, "Закрыть дневник") }
            }
            Spacer(Modifier.height(12.dp))
            Button(onClick = { editEntry = null; text = ""; mood = "Спокойно"; editor = true }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.Add, null); Text("Новая запись") }
            Spacer(Modifier.height(12.dp))
            if (entries.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Записей пока нет. И это тоже нормально.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(entries, key = { it.id }) { entry ->
                    Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().clickable { showEntry = entry }) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(SimpleDateFormat("d MMMM yyyy, HH:mm", Locale("ru")).format(Date(entry.createdAt)), style = MaterialTheme.typography.labelMedium)
                                Text(entry.mood, style = MaterialTheme.typography.titleMedium)
                                Text("Нажми, чтобы прочитать", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            IconButton(onClick = { editEntry = entry; text = vm.decrypt(entry).orEmpty(); mood = entry.mood; editor = true }) { Icon(Icons.Rounded.Edit, "Редактировать") }
                            IconButton(onClick = { vm.delete(entry.id) }) { Icon(Icons.Rounded.DeleteOutline, "Удалить") }
                        }
                    }
                }
            }
        }
    }

    if (editor) {
        AlertDialog(
            onDismissRequest = { editor = false },
            title = { Text(if (editEntry == null) "Новая запись" else "Редактировать запись") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Как ты себя чувствуешь?")
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        listOf("Тяжело", "Грустно", "Спокойно", "Хорошо").forEach {
                            FilterChip(selected = mood == it, onClick = { mood = it }, label = { Text(it) })
                        }
                    }
                    OutlinedTextField(text, { text = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 150.dp), label = { Text("Твои мысли…") })
                }
            },
            confirmButton = { TextButton(onClick = { if (text.isNotBlank()) vm.save(text, mood, editEntry); editor = false }) { Text("Сохранить") } },
            dismissButton = { TextButton(onClick = { editor = false }) { Text("Отмена") } }
        )
    }
    showEntry?.let { entry ->
        AlertDialog(
            onDismissRequest = { showEntry = null },
            title = { Text("${entry.mood} · ${SimpleDateFormat("d MMM yyyy", Locale("ru")).format(Date(entry.createdAt))}") },
            text = { Text(vm.decrypt(entry) ?: "Не удалось расшифровать запись.") },
            confirmButton = { TextButton(onClick = { showEntry = null }) { Text("Закрыть") } }
        )
    }
}
