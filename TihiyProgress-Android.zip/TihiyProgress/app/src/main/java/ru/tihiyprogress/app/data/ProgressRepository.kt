package ru.tihiyprogress.app.data

import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

class ProgressRepository(private val dao: AppDao) {
    val tasks: Flow<List<TaskEntity>> = dao.observeTasks()
    val entries: Flow<List<DiaryEntryEntity>> = dao.observeEntries()

    suspend fun stats(): StatsEntity = dao.getStats() ?: StatsEntity().also { dao.saveStats(it) }

    suspend fun addTask(title: String, reward: Int) =
        dao.insertTask(TaskEntity(title = title, reward = reward.coerceIn(5, 50)))

    suspend fun updateTask(task: TaskEntity) = dao.updateTask(task)
    suspend fun deleteTask(task: TaskEntity) = dao.deleteTask(task)

    suspend fun completeTask(reward: Int): Pair<StatsEntity, Boolean> {
        val today = LocalDate.now().toString()
        val old = stats()
        val yesterday = LocalDate.now().minusDays(1).toString()
        val wasActiveYesterday = old.lastActiveDate == yesterday
        val streak = when {
            old.lastActiveDate == today -> old.streak.coerceAtLeast(1)
            wasActiveYesterday -> old.streak + 1
            else -> 1
        }
        val reset = old.lastActiveDate.isNotBlank() &&
            old.lastActiveDate != today && old.lastActiveDate != yesterday && old.streak > 0
        val updated = old.copy(
            xp = old.xp + reward,
            streak = streak,
            lastActiveDate = today
        )
        dao.saveStats(updated)
        return updated to reset
    }

    suspend fun claimBase(): Pair<Boolean, Boolean> {
        val today = LocalDate.now().toString()
        val old = stats()
        if (old.lastBaseDate == today) return false to false
        val (updated, reset) = completeTask(5)
        dao.saveStats(updated.copy(lastBaseDate = today))
        return true to reset
    }

    suspend fun claimDaily(): Pair<StatsEntity, Boolean>? {
        val today = LocalDate.now().toString()
        if (stats().dailyDate == today) return null
        val (updated, reset) = completeTask(30)
        val saved = updated.copy(dailyDate = today)
        dao.saveStats(saved)
        return saved to reset
    }

    suspend fun dailyDate(): String = stats().dailyDate
    suspend fun markDailyDate(date: String) {
        val old = stats()
        dao.saveStats(old.copy(dailyDate = date))
    }

    suspend fun security() = dao.getSecurity()
    suspend fun saveSecurity(value: DiarySecurityEntity) = dao.saveSecurity(value)
    suspend fun addEntry(entry: DiaryEntryEntity) = dao.insertEntry(entry)
    suspend fun updateEntry(entry: DiaryEntryEntity) = dao.updateEntry(entry)
    suspend fun deleteEntry(id: Long) = dao.deleteEntry(id)
}
