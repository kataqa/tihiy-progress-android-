package ru.tihiyprogress.app.data

import android.util.Base64
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Локальное шифрование дневника: ключ выводится из пароля через PBKDF2,
 * записи шифруются AES/GCM. Пароль и ключ в базе не сохраняются.
 */
object DiaryCrypto {
    private const val ITERATIONS = 150_000
    private const val KEY_BITS = 256

    private fun derive(password: CharArray, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password, salt, ITERATIONS, KEY_BITS)
        return try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                .generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    fun createSecurity(password: CharArray): Pair<DiarySecurityEntity, ByteArray> {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val key = derive(password, salt)
        val verifier = derive(("verify:" + Base64.encodeToString(key, Base64.NO_WRAP)).toCharArray(), salt)
        return DiarySecurityEntity(
            salt = Base64.encodeToString(salt, Base64.NO_WRAP),
            verifier = Base64.encodeToString(verifier, Base64.NO_WRAP)
        ) to key
    }

    fun unlock(password: CharArray, security: DiarySecurityEntity): ByteArray? {
        val salt = Base64.decode(security.salt, Base64.NO_WRAP)
        val key = derive(password, salt)
        val verifier = derive(("verify:" + Base64.encodeToString(key, Base64.NO_WRAP)).toCharArray(), salt)
        val expected = Base64.decode(security.verifier, Base64.NO_WRAP)
        return if (java.security.MessageDigest.isEqual(verifier, expected)) key else null
    }

    fun encrypt(text: String, key: ByteArray): Pair<String, String> {
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        val encrypted = cipher.doFinal(text.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(encrypted, Base64.NO_WRAP) to
            Base64.encodeToString(iv, Base64.NO_WRAP)
    }

    fun decrypt(data: String, ivText: String, key: ByteArray): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(
            Cipher.DECRYPT_MODE,
            SecretKeySpec(key, "AES"),
            GCMParameterSpec(128, Base64.decode(ivText, Base64.NO_WRAP))
        )
        return cipher.doFinal(Base64.decode(data, Base64.NO_WRAP)).toString(Charsets.UTF_8)
    }
}
