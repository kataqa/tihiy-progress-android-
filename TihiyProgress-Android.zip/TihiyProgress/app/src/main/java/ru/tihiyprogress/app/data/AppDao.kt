package ru.tihiyprogress.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    @Query("SELECT * FROM tasks ORDER BY id")
    fun observeTasks(): Flow<List<TaskEntity>>

    @Insert
    suspend fun insertTask(task: TaskEntity)

    @Update
    suspend fun updateTask(task: TaskEntity)

    @Delete
    suspend fun deleteTask(task: TaskEntity)

    @Query("SELECT * FROM app_stats WHERE id = 1")
    suspend fun getStats(): StatsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveStats(stats: StatsEntity)

    @Query("SELECT * FROM diary_entries ORDER BY createdAt DESC")
    fun observeEntries(): Flow<List<DiaryEntryEntity>>

    @Insert
    suspend fun insertEntry(entry: DiaryEntryEntity)

    @Update
    suspend fun updateEntry(entry: DiaryEntryEntity)

    @Query("DELETE FROM diary_entries WHERE id = :id")
    suspend fun deleteEntry(id: Long)

    @Query("SELECT * FROM diary_security WHERE id = 1")
    suspend fun getSecurity(): DiarySecurityEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSecurity(security: DiarySecurityEntity)
}
