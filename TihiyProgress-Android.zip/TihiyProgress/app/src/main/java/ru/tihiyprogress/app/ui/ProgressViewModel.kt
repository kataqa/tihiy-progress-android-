package ru.tihiyprogress.app.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ru.tihiyprogress.app.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate

data class ProgressUiState(
    val stats: StatsEntity = StatsEntity(),
    val dailyTask: String = "",
    val baseClaimed: Boolean = false,
    val dailyClaimed: Boolean = false,
    val message: String? = null
)

class ProgressViewModel(private val repo: ProgressRepository) : ViewModel() {
    val tasks = repo.tasks.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val entries = repo.entries.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    private val _state = MutableStateFlow(ProgressUiState())
    val state = _state.asStateFlow()

    private val dailyTasks = listOf(
        "Выпить стакан воды", "Открыть окно и немного подышать",
        "Умыться или просто освежить лицо", "Выйти на улицу на пять минут",
        "Написать человеку, с которым спокойно", "Съесть что-нибудь простое",
        "Переодеться в чистую одежду", "Послушать одну любимую песню",
        "Потянуться хотя бы полминуты", "Убрать одну маленькую вещь на место",
        "Побыть без телефона две минуты", "Сделать несколько спокойных вдохов",
        "Посмотреть в окно и заметить три вещи вокруг", "Почистить зубы",
        "Погладить питомца или укутаться в плед"
    )

    init { refresh() }

    fun refresh() = viewModelScope.launch {
        val stats = repo.stats()
        val today = LocalDate.now().toString()
        val daily = dailyTasks[(LocalDate.now().toEpochDay().toInt().mod(dailyTasks.size))]
        _state.update {
            it.copy(
                stats = stats,
                dailyTask = daily,
                baseClaimed = stats.lastBaseDate == today,
                dailyClaimed = stats.dailyDate == today
            )
        }
    }

    fun addTask(title: String, reward: Int) = viewModelScope.launch {
        if (title.isNotBlank()) repo.addTask(title.trim(), reward)
    }

    fun editTask(task: TaskEntity, title: String, reward: Int) = viewModelScope.launch {
        if (title.isNotBlank()) repo.updateTask(task.copy(title = title.trim(), reward = reward))
    }

    fun deleteTask(task: TaskEntity) = viewModelScope.launch { repo.deleteTask(task) }

    fun completeTask(reward: Int) = viewModelScope.launch {
        val before = _state.value.stats.xp
        val (stats, reset) = repo.completeTask(reward)
        val levelUp = level(stats.xp) > level(before)
        _state.update {
            it.copy(
                stats = stats,
                message = when {
                    levelUp -> "Новый уровень. Ты постепенно движешься в своём темпе."
                    reset -> "Новая серия начинается не с нуля. Всё, что ты делал раньше, всё ещё важно."
                    else -> "Готово. Даже маленький шаг имеет значение."
                }
            )
        }
    }

    fun claimBase() = viewModelScope.launch {
        val (claimed, reset) = repo.claimBase()
        if (claimed) refreshWithMessage(
            if (reset) "Начать заново — не значит всё потерять. Спасибо, что ты здесь."
            else "Спасибо, что заглянул(а). Сегодня этого уже достаточно."
        ) else _state.update {
            it.copy(message = "Ты уже получил(а) опыт за этот шаг сегодня. Можно просто побыть здесь.")
        }
    }

    fun claimDaily() = viewModelScope.launch {
        val result = repo.claimDaily()
        if (result == null) {
            _state.update { it.copy(message = "Задание дня уже отмечено. На сегодня достаточно.") }
        } else {
            val (_, reset) = result
            refreshWithMessage(if (reset) "Начать снова — не значит всё потерять. +30 XP" else "Ты сделал(а) это. +30 XP")
        }
    }

    fun adoptDaily() = addTask(_state.value.dailyTask, 10)

    private suspend fun refreshWithMessage(message: String) {
        val stats = repo.stats()
        val today = LocalDate.now().toString()
        _state.update { it.copy(
            stats = stats,
            baseClaimed = stats.lastBaseDate == today,
            dailyClaimed = stats.dailyDate == today,
            message = message
        ) }
    }

    fun clearMessage() { _state.update { it.copy(message = null) } }

    companion object {
        // Формула уровня: меняй делитель 50 здесь, если захочешь другой темп.
        fun level(xp: Int): Int = kotlin.math.floor(kotlin.math.sqrt(xp.coerceAtLeast(0) / 50.0)).toInt() + 1
        fun xpForNextLevel(level: Int): Int = level * level * 50
    }
}
